/* Wireframe primitive components — small, low-fi building blocks */

const Browser = ({ url = "yuvatravel.com", children }) => (
  <div className="wf-browser">
    <div className="wf-browser-bar">
      <span className="dot" />
      <span className="dot" />
      <span className="dot" />
      <span className="url">⌂ {url}</span>
    </div>
    {children}
  </div>
);

const WfNav = ({ active = "Home" }) => {
  const items = ["首頁", "文章", "標籤", "搜尋", "Q&A"];
  return (
    <div className="wf-nav">
      <div className="wf-nav-logo">域見 · YUVATRAVEL</div>
      <div className="wf-nav-items">
        {items.map(i => (
          <span key={i} className={i === active ? "active" : ""}>{i}</span>
        ))}
      </div>
      <span className="wf-nav-cta">開始媒合</span>
    </div>
  );
};

/* image placeholder with optional aspect via height/style */
const Img = ({ height = 120, label = "IMG", style = {} }) => (
  <div className="wf-img" style={{ height, ...style }}>
    <span>{label}</span>
  </div>
);

/* faux-handwritten paragraph: N text-line bars */
const Lines = ({ n = 3, last = "shorter" }) => (
  <div className="wf-textblock">
    {Array.from({ length: n - 1 }).map((_, i) => (
      <div key={i} className="wf-line" />
    ))}
    <div className={`wf-line ${last}`} />
  </div>
);

const Heading = ({ children, size = "" }) => (
  <h3 className={`wf-heading ${size}`}>{children}</h3>
);

const Eyebrow = ({ children }) => (
  <div className="wf-eyebrow">{children}</div>
);

const Btn = ({ variant = "primary", children }) => (
  <span className={`wf-btn ${variant}`}>{children}</span>
);

const Chip = ({ dark, count, children }) => (
  <span className={`wf-chip ${dark ? "dark" : ""}`}>
    {children}
    {count != null && <span className="count">·{count}</span>}
  </span>
);

const GoldRule = ({ short, soft, style = {} }) => (
  <hr className={`wf-rule ${short ? "short" : ""} ${soft ? "soft" : ""}`} style={style} />
);

const Pagination = ({ active = 1, total = 6 }) => (
  <div className="wf-pagination">
    <span className="pg">‹</span>
    {Array.from({ length: total }).map((_, i) => (
      <span key={i} className={`pg ${i + 1 === active ? "active" : ""}`}>{i + 1}</span>
    ))}
    <span className="pg">›</span>
  </div>
);

const Search = ({ size = "md", pill, placeholder = "搜尋文章、標籤、地點..." }) => (
  <div className={`wf-search ${size === "lg" ? "lg" : ""} ${pill ? "pill" : ""}`}>
    <span>⌕</span>
    <span style={{ flex: 1 }}>{placeholder}</span>
  </div>
);

const Note = ({ top, left, right, bottom, children }) => (
  <div className="wf-note" style={{ top, left, right, bottom }}>
    {children}
  </div>
);

/* —— Article cards —— */

/* Card variant A: featured home card — image left, title + views on right */
const HomeCardA = () => (
  <div style={{ display: "flex", gap: 10, padding: 10, border: "1.2px solid var(--line-soft)", borderRadius: 4, background: "#fff" }}>
    <Img height={70} style={{ width: 100, flexShrink: 0 }} label="IMG" />
    <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", minWidth: 0 }}>
      <div className="text-hand" style={{ fontSize: 16, color: "var(--navy)", lineHeight: 1.2 }}>
        在京都的雨裡 走一段東山
      </div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>
        ◉ 1,284 views
      </div>
    </div>
  </div>
);

/* Card variant B: stacked (image top, title, views) */
const HomeCardB = () => (
  <div style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, overflow: "hidden" }}>
    <Img height={90} label="IMG" />
    <div style={{ padding: 10 }}>
      <div className="text-hand" style={{ fontSize: 16, color: "var(--navy)", lineHeight: 1.2 }}>
        台南老巷的清晨
      </div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", marginTop: 6 }}>
        ◉ 2,041 views
      </div>
    </div>
  </div>
);

/* Card variant C: editorial — large image, overlay caption */
const HomeCardC = () => (
  <div style={{ position: "relative", borderRadius: 4, overflow: "hidden", border: "1.2px solid var(--line-soft)" }}>
    <Img height={140} label="IMG · large" />
    <div style={{
      position: "absolute", left: 10, right: 10, bottom: 10,
      background: "rgba(11,34,64,.78)", color: "var(--paper)",
      padding: "6px 10px", borderRadius: 3
    }}>
      <div className="text-hand" style={{ fontSize: 16, lineHeight: 1.1 }}>清邁的星期天市場</div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 9, color: "rgba(250,247,238,.7)", marginTop: 2 }}>◉ 938</div>
    </div>
  </div>
);

/* —— Article list cards (with tags) —— */

/* Variant A: horizontal — image left, content right with tags */
const ListCardA = () => (
  <div style={{ display: "flex", gap: 12, padding: 12, borderTop: "1.2px solid var(--line-soft)", borderBottom: "1.2px solid var(--line-soft)", background: "#fff" }}>
    <Img height={84} style={{ width: 130, flexShrink: 0 }} label="IMG" />
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
      <Eyebrow>JOURNAL · 03</Eyebrow>
      <div className="text-hand" style={{ fontSize: 18, color: "var(--navy)", lineHeight: 1.15 }}>
        台南老巷的清晨 · 與美玲走一段
      </div>
      <Lines n={2} last="short" />
      <div className="wf-flex gap-6 mt-4" style={{ flexWrap: "wrap" }}>
        <Chip>#台南</Chip>
        <Chip>#早餐</Chip>
        <Chip>#在地</Chip>
      </div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", marginTop: 4 }}>
        ◉ 2,041 views &nbsp;·&nbsp; 8 分鐘
      </div>
    </div>
  </div>
);

/* Variant B: vertical card — full width with all elements stacked */
const ListCardB = () => (
  <div style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, overflow: "hidden" }}>
    <Img height={120} label="IMG" />
    <div style={{ padding: 12 }}>
      <Eyebrow>JOURNAL · 02</Eyebrow>
      <div className="text-hand mt-4" style={{ fontSize: 18, color: "var(--navy)", lineHeight: 1.15 }}>
        京都的雨．東山的茶
      </div>
      <Lines n={2} last="shorter" />
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        <Chip>#京都</Chip>
        <Chip>#茶道</Chip>
      </div>
      <div className="wf-flex between mt-8" style={{ alignItems: "center" }}>
        <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>◉ 1,128</div>
        <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>12 分鐘</div>
      </div>
    </div>
  </div>
);

/* —— Tag chip with count (component #3) —— */
const TagChip = ({ size = "md", count, children, active }) => {
  const sizes = {
    sm: { fontSize: 13, padding: "2px 8px" },
    md: { fontSize: 16, padding: "4px 12px" },
    lg: { fontSize: 22, padding: "6px 16px" },
    xl: { fontSize: 28, padding: "8px 20px" },
  };
  return (
    <span className={`wf-chip ${active ? "dark" : ""}`} style={sizes[size]}>
      {children}{count != null && <span className="count">·{count}</span>}
    </span>
  );
};

Object.assign(window, {
  Browser, WfNav, Img, Lines, Heading, Eyebrow, Btn, Chip, GoldRule,
  Pagination, Search, Note, HomeCardA, HomeCardB, HomeCardC,
  ListCardA, ListCardB, TagChip,
});
