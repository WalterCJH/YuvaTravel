/* FAQ page — 3 wireframe variations */

const faqs = [
  { q: "如何開始媒合？", a: "點擊「開始媒合」，告訴我們你想去的地方、想試的事，以及讓旅程慢下來的方式。" },
  { q: "媒合需要多久時間？", a: "通常 24 小時內，我們會從在地嚮導中為你挑選 2–3 位最相近的可能。" },
  { q: "費用怎麼計算？", a: "嚮導費由嚮導訂價，依日計費。媒合服務本身不向旅人收費。" },
  { q: "如果不滿意嚮導怎麼辦？", a: "在出發前，我們可以重新媒合一次。若旅程中有問題，請與我們聯繫。" },
  { q: "可以指定語言嗎？", a: "可以。多數嚮導能以中文、英文溝通，部分提供日文、泰文等。" },
  { q: "支援哪些地區？", a: "目前涵蓋台灣、日本、泰國、印尼、越南等亞洲十餘城市。持續擴充中。" },
];

const FaqV1 = () => (
  <Browser url="yuvatravel.com/faq">
    <WfNav active="Q&A" />
    <div className="wf-section text-center">
      <Eyebrow>FAQ · 常見問答</Eyebrow>
      <Heading size="lg">關於域見</Heading>
      <div className="text-hand text-soft" style={{ fontSize: 14 }}>有疑問？這裡可能有答案。</div>
    </div>

    {/* simple stacked accordion list */}
    <div className="wf-section" style={{ position: "relative" }}>
      {faqs.map((f, i) => (
        <div key={i} className="wf-acc">
          <div style={{ flex: 1 }}>
            <div className="q">Q{i + 1}. {f.q}</div>
            {i < 2 && <div className="a">{f.a}</div>}
          </div>
          <span className="ico">{i < 2 ? "−" : "+"}</span>
        </div>
      ))}
      <Note top={-2} right={-2}>點擊展開<br />Accordion</Note>
    </div>

    {/* contact strip */}
    <div className="wf-section bg-paper-2 text-center">
      <GoldRule short style={{ margin: "0 auto 8px" }} />
      <div className="text-hand text-navy" style={{ fontSize: 18 }}>沒找到答案？</div>
      <div className="wf-flex center mt-8">
        <Btn variant="ghost">寫信給我們 →</Btn>
      </div>
    </div>
  </Browser>
);

const FaqV2 = () => (
  <Browser url="yuvatravel.com/faq">
    <WfNav active="Q&A" />
    <div className="wf-section">
      <Eyebrow>FAQ</Eyebrow>
      <Heading size="lg">常見問答</Heading>
    </div>

    {/* sidebar categories + content */}
    <div style={{ display: "grid", gridTemplateColumns: "0.8fr 2fr", gap: 0, position: "relative" }}>
      <div style={{ background: "var(--paper-2)", padding: 16, borderRight: "1.5px solid var(--gold-soft)" }}>
        <h4 className="text-hand text-navy" style={{ margin: 0, fontSize: 16 }}>分類</h4>
        <GoldRule short style={{ margin: "6px 0 10px" }} />
        <div className="wf-flex col gap-6">
          {[
            { c: "媒合流程", n: 6, active: true },
            { c: "費用 · 付款", n: 4 },
            { c: "嚮導相關", n: 5 },
            { c: "行程變更", n: 3 },
            { c: "隱私 · 資料", n: 2 },
          ].map(g => (
            <div key={g.c} className="wf-flex between" style={{
              alignItems: "baseline",
              padding: "4px 8px",
              borderLeft: g.active ? "2px solid var(--gold)" : "2px solid transparent",
              background: g.active ? "#fff" : "transparent",
            }}>
              <span className="text-hand" style={{ fontSize: 14, color: g.active ? "var(--navy)" : "var(--ink-soft)" }}>{g.c}</span>
              <span style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>{g.n}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: 16 }}>
        <Eyebrow>媒合流程</Eyebrow>
        <Heading>關於媒合</Heading>
        <div className="mt-12">
          {faqs.slice(0, 4).map((f, i) => (
            <div key={i} className="wf-acc">
              <div style={{ flex: 1 }}>
                <div className="q">{f.q}</div>
                {i === 0 && <div className="a">{f.a}</div>}
              </div>
              <span className="ico">{i === 0 ? "−" : "+"}</span>
            </div>
          ))}
        </div>
      </div>
      <Note top={-2} right={-2}>左分類 · 右內容</Note>
    </div>
  </Browser>
);

const FaqV3 = () => (
  <Browser url="yuvatravel.com/faq">
    <WfNav active="Q&A" />
    <div className="wf-section text-center">
      <Eyebrow>HELP · 我們可以幫你</Eyebrow>
      <Heading size="lg">有什麼問題？</Heading>
      <div style={{ maxWidth: 360, margin: "12px auto 0" }}>
        <Search size="lg" pill placeholder="搜尋常見問題..." />
      </div>
    </div>

    {/* category cards */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        {[
          { c: "媒合流程", n: 6, ico: "✦" },
          { c: "費用 · 付款", n: 4, ico: "$" },
          { c: "嚮導相關", n: 5, ico: "◉" },
          { c: "行程變更", n: 3, ico: "↻" },
          { c: "隱私 · 資料", n: 2, ico: "⌂" },
          { c: "其他", n: 4, ico: "?" },
        ].map(g => (
          <div key={g.c} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, padding: 12, textAlign: "center" }}>
            <div className="text-gold" style={{ fontSize: 22, fontFamily: "var(--serif)" }}>{g.ico}</div>
            <div className="text-hand text-navy mt-4" style={{ fontSize: 16, fontWeight: 700 }}>{g.c}</div>
            <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", marginTop: 2 }}>{g.n} 個問題</div>
          </div>
        ))}
      </div>
      <Note top={-2} right={-2}>搜尋 + 分類卡<br />+ 下方 accordion</Note>
    </div>

    {/* popular questions */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>熱門問題</Eyebrow>
      <div className="mt-8">
        {faqs.slice(0, 4).map((f, i) => (
          <div key={i} className="wf-acc" style={{ borderColor: "var(--line-soft)" }}>
            <div style={{ flex: 1 }}>
              <div className="q">{f.q}</div>
              {i === 0 && <div className="a">{f.a}</div>}
            </div>
            <span className="ico">{i === 0 ? "−" : "+"}</span>
          </div>
        ))}
      </div>
    </div>
  </Browser>
);

Object.assign(window, { FaqV1, FaqV2, FaqV3 });
