/* HOME page — 3 wireframe variations */

const HomeV1 = () => (
  <Browser url="yuvatravel.com">
    <WfNav active="首頁" />
    {/* hero — editorial: type left, image right */}
    <div className="wf-section" style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, position: "relative" }}>
      <div>
        <Eyebrow>PRIVATE CURATION · 私訪旅誌</Eyebrow>
        <Heading size="xl">域見</Heading>
        <div className="text-hand" style={{ fontSize: 18, color: "var(--ink-soft)", marginTop: 4, lineHeight: 1.3 }}>
          找到那個真正在地的人 · 走一段不在攻略上的旅程。
        </div>
        <div className="wf-flex gap-8 mt-12">
          <Btn variant="primary">開始媒合 →</Btn>
          <Btn variant="ghost">瀏覽嚮導</Btn>
        </div>
      </div>
      <Img height={170} label="HERO IMG · 直幅" />
      <Note top={4} right={-2}>大標 + 圖片左右排版</Note>
    </div>

    {/* featured articles — 3 home cards */}
    <div className="wf-section">
      <div className="wf-flex between mb-8" style={{ alignItems: "baseline" }}>
        <Heading>精選文章</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 14 }}>看全部 →</span>
      </div>
      <div className="wf-grid col-3">
        <HomeCardB /><HomeCardB /><HomeCardB />
      </div>
    </div>

    {/* destinations / theme strip */}
    <div className="wf-section">
      <Eyebrow>主題分類</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {["#京都", "#台南", "#清邁", "#東京", "#峇里島", "#曼谷"].map(t => <Chip key={t}>{t}</Chip>)}
      </div>
    </div>

    {/* journal CTA — quote + button */}
    <div className="wf-section bg-paper-2 text-center">
      <GoldRule short style={{ margin: "0 auto 8px" }} />
      <div className="text-hand" style={{ fontSize: 18, color: "var(--navy)", fontStyle: "italic", lineHeight: 1.3 }}>
        "最好的地方不在任何清單上 — <br />那扇門需要有人為你打開。"
      </div>
    </div>
  </Browser>
);

const HomeV2 = () => (
  <Browser url="yuvatravel.com">
    <WfNav active="首頁" />
    {/* full-bleed banner with overlay text */}
    <div style={{ position: "relative" }}>
      <Img height={200} label="BANNER · full-bleed image" />
      <div style={{ position: "absolute", left: 18, bottom: 18, color: "var(--paper)", textShadow: "0 1px 4px rgba(0,0,0,.4)" }}>
        <div className="wf-eyebrow" style={{ color: "var(--gold-soft)" }}>BANNER</div>
        <div className="text-hand" style={{ fontSize: 32, fontWeight: 700, lineHeight: 1 }}>慢一點 看世界</div>
      </div>
      <Note top={4} left={6}>整版 banner 圖<br />覆蓋大標</Note>
    </div>

    {/* mosaic articles — 1 large + 2 small */}
    <div className="wf-section">
      <div className="wf-flex between mb-8" style={{ alignItems: "baseline" }}>
        <Heading>熱門文章</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 14 }}>更多 →</span>
      </div>
      <div className="wf-grid" style={{ gridTemplateColumns: "1.3fr 1fr", gap: 10 }}>
        <HomeCardC />
        <div className="wf-flex col gap-8">
          <HomeCardA />
          <HomeCardA />
        </div>
      </div>
    </div>

    {/* travel tips block */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>旅行小撇步</Eyebrow>
      <div className="wf-grid col-3 mt-8">
        {[1, 2, 3].map(i => (
          <div key={i} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", padding: 10, borderRadius: 4 }}>
            <div className="text-hand text-navy" style={{ fontSize: 26, fontStyle: "italic" }}>0{i}</div>
            <GoldRule short style={{ width: 24, margin: "4px 0" }} />
            <div className="text-hand" style={{ fontSize: 14, color: "var(--ink-soft)", lineHeight: 1.3 }}>
              {i === 1 ? "出發前 一句話寫信給嚮導" : i === 2 ? "帶一本可寫的紙本旅誌" : "預留一個沒有計畫的早晨"}
            </div>
          </div>
        ))}
      </div>
    </div>

    {/* local guides — grid of guide cards (variant A) */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex between mb-8" style={{ alignItems: "baseline" }}>
        <div>
          <Eyebrow>LOCAL GUIDES · 在地嚮導</Eyebrow>
          <Heading>找一個帶你看見真實的人</Heading>
        </div>
        <span className="text-hand text-soft" style={{ fontSize: 14 }}>所有嚮導 →</span>
      </div>
      <div className="wf-grid col-3 mt-8" style={{ gap: 10 }}>
        <GuideCardA name="美咲" en="Misaki" city="京都" years={7} langs="JP · EN" tags={["茶道", "寺廟", "清晨"]} articles={12} rating={4.9} />
        <GuideCardA name="美玲" en="Mei-Ling" city="台南" years={5} langs="ZH · EN" tags={["早餐", "市場", "在地"]} articles={15} rating={5.0} />
        <GuideCardA name="阿諾" en="Arnon" city="清邁" years={9} langs="TH · EN" tags={["市場", "山徑", "夜晚"]} articles={8} rating={4.9} />
      </div>
      <Note top={-2} right={-2}>嚮導卡 A · 3 欄</Note>
    </div>

    {/* newsletter strip */}
    <div className="wf-section bg-navy" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
      <div className="text-hand" style={{ color: "var(--paper)", fontSize: 18 }}>每月一封 · 旅誌訂閱</div>
      <div style={{ background: "var(--paper)", borderRadius: 4, padding: "4px 10px", fontFamily: "var(--hand)", fontSize: 14, color: "var(--ink-light)", flex: 1, maxWidth: 180 }}>your@email</div>
      <Btn variant="ghost">訂閱</Btn>
    </div>

    {/* themes / categories */}
    <div className="wf-section">
      <Eyebrow>主題分類</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {["#京都", "#台南", "#清邁", "#東京", "#峇里島", "#曼谷"].map(t => <Chip key={t}>{t}</Chip>)}
      </div>
    </div>
  </Browser>
);

const HomeV3 = () => (
  <Browser url="yuvatravel.com">
    <WfNav active="首頁" />
    {/* compact hero with search */}
    <div className="wf-section text-center" style={{ position: "relative" }}>
      <Eyebrow>YUVATRAVEL · 私訪旅誌</Eyebrow>
      <Heading size="lg">你想去哪裡？</Heading>
      <div style={{ maxWidth: 320, margin: "10px auto 0" }}>
        <Search size="lg" pill placeholder="輸入地點或主題..." />
      </div>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap", justifyContent: "center" }}>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>熱門：</span>
        {["京都茶道", "台南早餐", "清邁市場"].map(t => (
          <span key={t} className="text-hand text-navy" style={{ fontSize: 14, borderBottom: "1.5px solid var(--gold-soft)" }}>{t}</span>
        ))}
      </div>
      <Note top={4} right={4}>搜尋型首頁<br />讓人直接找</Note>
    </div>

    {/* split: latest articles | side widget */}
    <div className="wf-section" style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16 }}>
      <div>
        <Heading>最新文章</Heading>
        <div className="wf-grid col-2 mt-8" style={{ gap: 12 }}>
          <HomeCardB /><HomeCardB />
          <HomeCardB /><HomeCardB />
        </div>
      </div>
      <div className="wf-side">
        <h4>熱門標籤</h4>
        <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
          {["京都", "台南", "茶道", "市場", "清晨", "在地"].map(t => (
            <Chip key={t} count={Math.floor(Math.random() * 40) + 5}>#{t}</Chip>
          ))}
        </div>
        <h4 style={{ marginTop: 16 }}>排行榜</h4>
        <div className="wf-flex col gap-8">
          {["在京都的雨裡", "台南牛肉湯之味", "清邁山徑與寺廟"].map((t, i) => (
            <div key={t} className="wf-flex gap-8" style={{ alignItems: "baseline" }}>
              <span className="text-hand text-gold" style={{ fontSize: 22, fontStyle: "italic", width: 22 }}>{i + 1}</span>
              <span className="text-hand text-navy" style={{ fontSize: 14 }}>{t}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </Browser>
);

Object.assign(window, { HomeV1, HomeV2, HomeV3 });
