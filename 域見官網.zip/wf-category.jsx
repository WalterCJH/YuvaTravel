/* ARTICLE CATEGORY page — 3 wireframe variations */

const cats = ["全部", "京都", "台南", "清邁", "東京", "峇里島", "曼谷"];
const tagsList = ["#早餐", "#茶道", "#市場", "#夜晚", "#寺廟", "#山徑", "#在地", "#清晨"];

const CategoryV1 = () => (
  <Browser url="yuvatravel.com/articles/京都">
    <WfNav active="文章" />
    {/* page header */}
    <div className="wf-section">
      <Eyebrow>CATEGORY · 文章分類</Eyebrow>
      <Heading size="lg">京都 · Kyoto</Heading>
      <div className="text-hand text-soft" style={{ fontSize: 14 }}>共 24 篇 · 慢一點看世界</div>
    </div>

    {/* category chips row */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
        {cats.map((c, i) => <Chip key={c} dark={i === 1}>{c}</Chip>)}
      </div>
      <Note top={-4} right={-2}>分類置頂橫排</Note>
    </div>

    {/* main: list with bottom tag cloud */}
    <div style={{ padding: 16 }}>
      <div className="wf-flex col gap-12">
        <ListCardA /><ListCardA /><ListCardA /><ListCardA />
        <div className="wf-flex center mt-8">
          <Pagination active={2} total={5} />
        </div>
      </div>
    </div>

    {/* tag cloud bottom — moved from V3 */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>本分類熱門標籤</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {tagsList.map(t => <TagChip key={t} count={Math.floor(Math.random() * 25) + 2}>{t}</TagChip>)}
      </div>
    </div>
  </Browser>
);

const CategoryV2 = () => (
  <Browser url="yuvatravel.com/articles">
    <WfNav active="文章" />
    {/* compact head */}
    <div className="wf-section">
      <Eyebrow>JOURNAL</Eyebrow>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>所有文章</Heading>
        <div className="text-hand text-soft" style={{ fontSize: 13 }}>共 96 篇</div>
      </div>
    </div>

    {/* split layout — left rail = categories + tags, right = grid */}
    <div style={{ display: "grid", gridTemplateColumns: "0.8fr 2fr", gap: 16, padding: 16, position: "relative" }}>
      <div className="wf-flex col gap-16">
        <div>
          <h4 className="text-hand text-navy mb-4" style={{ fontSize: 16, margin: 0 }}>分類</h4>
          <GoldRule short style={{ margin: "6px 0 8px" }} />
          <div className="wf-flex col gap-4">
            {cats.map((c, i) => (
              <div key={c} className="wf-flex between" style={{ alignItems: "baseline", color: i === 0 ? "var(--navy)" : "var(--ink-soft)", borderLeft: i === 0 ? "2px solid var(--gold)" : "2px solid transparent", paddingLeft: 8 }}>
                <span className="text-hand" style={{ fontSize: 15 }}>{c}</span>
                <span style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>{Math.floor(Math.random() * 30) + 5}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h4 className="text-hand text-navy mb-4" style={{ fontSize: 16, margin: 0 }}>標籤</h4>
          <GoldRule short style={{ margin: "6px 0 8px" }} />
          <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
            {tagsList.slice(0, 6).map(t => <Chip key={t}>{t}</Chip>)}
          </div>
        </div>
      </div>
      <div>
        <div className="wf-grid col-2" style={{ gap: 12 }}>
          {[1, 2, 3, 4].map(i => <ListCardB key={i} />)}
        </div>
        <div className="wf-flex center mt-16">
          <Pagination active={1} total={6} />
        </div>
      </div>
      <Note top={-2} left={-4}>左側欄分類<br />右側網格</Note>
    </div>
  </Browser>
);

const CategoryV3 = () => (
  <Browser url="yuvatravel.com/articles/台南">
    <WfNav active="文章" />
    {/* breadcrumb + tabbed categories */}
    <div className="wf-section" style={{ paddingBottom: 0 }}>
      <div style={{ fontFamily: "var(--hand)", fontSize: 13, color: "var(--ink-light)" }}>
        首頁 / 文章 / <span style={{ color: "var(--navy)" }}>台南</span>
      </div>
      <div className="wf-flex between mt-8" style={{ alignItems: "baseline" }}>
        <Heading size="lg">台南</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>排序：最新 ▾</span>
      </div>
    </div>

    {/* tabs as section starter */}
    <div className="wf-section" style={{ borderBottom: "1.5px solid var(--gold-soft)", paddingTop: 8 }}>
      <div className="wf-flex gap-12">
        {cats.map((c, i) => (
          <span key={c} className="text-hand" style={{
            fontSize: 16,
            color: i === 2 ? "var(--navy)" : "var(--ink-light)",
            paddingBottom: 6,
            borderBottom: i === 2 ? "2px solid var(--gold)" : "2px solid transparent",
            cursor: "pointer"
          }}>{c}</span>
        ))}
      </div>
    </div>

    {/* magazine layout: 1 hero + grid */}
    <div className="wf-section">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
        <Img height={150} label="HERO 圖" />
        <div className="wf-flex col" style={{ justifyContent: "center" }}>
          <Eyebrow>FEATURED · 03</Eyebrow>
          <Heading size="lg">台南老巷的清晨</Heading>
          <Lines n={3} last="short" />
          <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
            <Chip>#早餐</Chip>
            <Chip>#在地</Chip>
            <Chip>#清晨</Chip>
          </div>
          <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", marginTop: 8 }}>◉ 2,041 views · 8 分鐘</div>
        </div>
      </div>
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        {[1, 2, 3].map(i => <HomeCardB key={i} />)}
      </div>
      <div className="wf-flex between mt-16" style={{ alignItems: "center" }}>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>第 1 頁 · 共 8 頁</span>
        <Pagination active={1} total={5} />
      </div>
    </div>

    {/* tag cloud bottom */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>本分類熱門標籤</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {tagsList.map(t => <TagChip key={t} count={Math.floor(Math.random() * 25) + 2}>{t}</TagChip>)}
      </div>
    </div>
  </Browser>
);

Object.assign(window, { CategoryV1, CategoryV2, CategoryV3 });
