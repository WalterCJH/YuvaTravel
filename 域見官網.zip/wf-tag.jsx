/* TAG page — 3 wireframe variations */

const allTags = [
  { name: "京都", count: 28 },
  { name: "台南", count: 24 },
  { name: "茶道", count: 18 },
  { name: "早餐", count: 16 },
  { name: "市場", count: 14 },
  { name: "清晨", count: 12 },
  { name: "在地", count: 22 },
  { name: "山徑", count: 9 },
  { name: "寺廟", count: 11 },
  { name: "夜晚", count: 7 },
  { name: "海邊", count: 6 },
  { name: "老巷", count: 13 },
  { name: "雨季", count: 5 },
  { name: "民宿", count: 8 },
  { name: "夜市", count: 10 },
  { name: "私房", count: 4 },
  { name: "慢活", count: 17 },
  { name: "嚮導", count: 21 },
  { name: "日本", count: 26 },
  { name: "泰國", count: 15 },
];

const sizeFor = (c) => {
  if (c >= 24) return "xl";
  if (c >= 16) return "lg";
  if (c >= 10) return "md";
  return "sm";
};

const TagV1 = () => (
  <Browser url="yuvatravel.com/tags">
    <WfNav active="標籤" />
    <div className="wf-section">
      <Eyebrow>TAGS · 所有標籤</Eyebrow>
      <Heading size="lg">標籤雲</Heading>
      <div className="text-hand text-soft" style={{ fontSize: 14 }}>共 {allTags.length} 個標籤 · 點擊探索</div>
    </div>

    {/* tag cloud — sized by count */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-cloud">
        {allTags.map(t => {
          const fontSize = 14 + (t.count / 28) * 26;
          return (
            <span key={t.name} className="t" style={{ fontSize }}>
              #{t.name}<span className="c">{t.count}</span>
            </span>
          );
        })}
      </div>
      <Note top={-2} right={-2}>大小依文章<br />數量變化</Note>
    </div>

    {/* selected tag preview */}
    <div className="wf-section bg-paper-2">
      <div className="wf-flex between mb-12" style={{ alignItems: "baseline" }}>
        <Heading>#京都 · 28 篇文章</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>看全部 →</span>
      </div>
      <div className="wf-grid col-2" style={{ gap: 10 }}>
        <ListCardB /><ListCardB />
      </div>
      <div className="wf-flex center mt-16">
        <Pagination active={1} total={4} />
      </div>
    </div>
  </Browser>
);

const TagV2 = () => (
  <Browser url="yuvatravel.com/tags/京都">
    <WfNav active="標籤" />
    <div className="wf-section">
      <Eyebrow>TAG</Eyebrow>
      <div className="wf-flex" style={{ alignItems: "baseline", gap: 12 }}>
        <Heading size="xl">#京都</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 16 }}>· 28 篇文章</span>
      </div>
      <div className="text-hand text-soft" style={{ fontSize: 14, marginTop: 4 }}>慢一點 · 走在千年的雨裡</div>
    </div>

    {/* layout: list left, all tags right */}
    <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16, padding: 16, position: "relative" }}>
      <div className="wf-flex col gap-12">
        <ListCardA />
        <ListCardA />
        <ListCardA />
        <div className="wf-flex center mt-8">
          <Pagination active={1} total={5} />
        </div>
      </div>
      <div className="wf-side">
        <h4>所有標籤</h4>
        <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
          {allTags.map(t => (
            <TagChip key={t.name} size={sizeFor(t.count)} count={t.count} active={t.name === "京都"}>
              #{t.name}
            </TagChip>
          ))}
        </div>
      </div>
      <Note top={-2} right={-2}>右側列出全部<br />標籤 + 數量</Note>
    </div>
  </Browser>
);

const TagV3 = () => (
  <Browser url="yuvatravel.com/tags">
    <WfNav active="標籤" />
    <div className="wf-section">
      <Eyebrow>TAG INDEX · 標籤索引</Eyebrow>
      <Heading size="lg">依字母 / 主題瀏覽</Heading>
    </div>

    {/* alphabet jump bar */}
    <div className="wf-section" style={{ paddingTop: 0 }}>
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap", alignItems: "center" }}>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>跳到：</span>
        {["地點", "主題", "季節", "風格", "時間"].map((g, i) => (
          <span key={g} className="text-hand" style={{
            fontSize: 14, color: i === 0 ? "var(--paper)" : "var(--navy)",
            background: i === 0 ? "var(--navy)" : "transparent",
            border: "1.5px solid " + (i === 0 ? "var(--navy)" : "var(--gold-soft)"),
            borderRadius: 999, padding: "2px 10px", cursor: "pointer"
          }}>{g}</span>
        ))}
      </div>
    </div>

    {/* grouped tag lists */}
    <div className="wf-section">
      {[
        { group: "地點 · Places", items: allTags.slice(0, 6) },
        { group: "主題 · Themes", items: allTags.slice(6, 14) },
        { group: "季節 · Season", items: allTags.slice(14, 20) },
      ].map(g => (
        <div key={g.group} style={{ marginBottom: 16 }}>
          <div className="wf-flex between mb-8" style={{ alignItems: "baseline" }}>
            <div className="text-hand text-navy" style={{ fontSize: 18, fontWeight: 700 }}>{g.group}</div>
            <GoldRule style={{ flex: 1, margin: "0 12px" }} />
            <span className="text-hand text-soft" style={{ fontSize: 12 }}>{g.items.length}</span>
          </div>
          <div className="wf-grid col-3" style={{ gap: 8 }}>
            {g.items.map(t => (
              <div key={t.name} className="wf-flex between" style={{
                alignItems: "baseline",
                padding: "6px 10px",
                background: "#fff",
                border: "1.2px solid var(--line-soft)",
                borderRadius: 4
              }}>
                <span className="text-hand text-navy" style={{ fontSize: 15 }}>#{t.name}</span>
                <span style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--ink-light)" }}>{t.count} 篇</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  </Browser>
);

Object.assign(window, { TagV1, TagV2, TagV3 });
