/* SEARCH page — 3 wireframe variations */

const hotKeywords = ["京都茶道", "台南早餐", "清邁市場", "私房路線", "嚮導推薦", "雨季旅行"];
const hotTags = [
  { name: "京都", count: 28 },
  { name: "在地", count: 22 },
  { name: "嚮導", count: 21 },
  { name: "茶道", count: 18 },
  { name: "慢活", count: 17 },
  { name: "早餐", count: 16 },
];

const SearchV1 = () => (
  <Browser url="yuvatravel.com/search">
    <WfNav active="搜尋" />
    {/* big search hero */}
    <div className="wf-section text-center" style={{ position: "relative", padding: 24 }}>
      <Eyebrow>SEARCH · 尋找你的旅程</Eyebrow>
      <Heading size="lg">你想去哪裡？</Heading>
      <div style={{ maxWidth: 360, margin: "10px auto 0" }}>
        <Search size="lg" pill placeholder="輸入地點、主題、嚮導..." />
      </div>
      <Note top={4} right={4}>初始狀態 ·<br />空搜尋頁</Note>
    </div>

    {/* hot keywords */}
    <div className="wf-section">
      <Eyebrow>熱門關鍵字</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {hotKeywords.map((k, i) => (
          <span key={k} className="text-hand" style={{
            fontSize: 16, color: "var(--navy)",
            display: "inline-flex", alignItems: "baseline", gap: 4,
            padding: "4px 12px",
            background: "var(--paper-2)", borderRadius: 999
          }}>
            <span className="text-gold" style={{ fontFamily: "var(--sans)", fontSize: 11, fontStyle: "italic" }}>{i + 1}</span>
            {k}
          </span>
        ))}
      </div>
    </div>

    {/* hot tags */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>熱門標籤</Eyebrow>
      <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
        {hotTags.map(t => <TagChip key={t.name} size="md" count={t.count}>#{t.name}</TagChip>)}
      </div>
    </div>
  </Browser>
);

const SearchV2 = () => (
  <Browser url="yuvatravel.com/search?q=京都">
    <WfNav active="搜尋" />
    {/* search bar (active state with query) */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, border: "2px solid var(--navy)", borderRadius: 4, padding: "8px 14px", background: "#fff" }}>
        <span style={{ color: "var(--navy)" }}>⌕</span>
        <span className="text-hand text-navy" style={{ fontSize: 22, flex: 1 }}>京都</span>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>✕ 清除</span>
      </div>
      <div className="text-hand text-soft mt-8" style={{ fontSize: 14 }}>
        找到 <span className="text-navy" style={{ fontWeight: 700 }}>28</span> 篇相關文章
      </div>
      <Note top={2} right={-2}>已輸入<br />搜尋結果</Note>
    </div>

    {/* result list with sidebar */}
    <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16, padding: 16 }}>
      <div className="wf-flex col gap-12">
        <ListCardA />
        <ListCardA />
        <ListCardA />
        <div className="wf-flex center mt-8">
          <Pagination active={1} total={5} />
        </div>
      </div>
      <div className="wf-flex col gap-16">
        <div className="wf-side">
          <h4>篩選</h4>
          <div className="wf-flex col gap-4">
            {["全部 · 28", "文章 · 22", "嚮導 · 4", "標籤 · 2"].map((f, i) => (
              <span key={f} className="text-hand" style={{ fontSize: 14, color: i === 0 ? "var(--navy)" : "var(--ink-soft)" }}>
                {i === 0 ? "● " : "○ "}{f}
              </span>
            ))}
          </div>
        </div>
        <div className="wf-side">
          <h4>相關標籤</h4>
          <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
            {hotTags.slice(0, 5).map(t => <Chip key={t.name} count={t.count}>#{t.name}</Chip>)}
          </div>
        </div>
      </div>
    </div>
  </Browser>
);

const SearchV3 = () => (
  <Browser url="yuvatravel.com/search">
    <WfNav active="搜尋" />
    {/* split: search panel left | results/recommendations right */}
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", minHeight: 500, position: "relative" }}>
      {/* left panel */}
      <div style={{ background: "var(--paper-2)", padding: 18, borderRight: "1.5px solid var(--gold-soft)" }}>
        <Eyebrow>FIND</Eyebrow>
        <Heading size="lg">搜尋</Heading>
        <div className="mt-12">
          <Search size="md" placeholder="關鍵字..." />
        </div>

        <div className="mt-16">
          <h4 className="text-hand text-navy" style={{ margin: 0, fontSize: 16 }}>最近搜尋</h4>
          <GoldRule short style={{ margin: "6px 0 8px" }} />
          <div className="wf-flex col gap-4">
            {["京都茶道", "台南早餐", "清邁"].map(s => (
              <div key={s} className="wf-flex between" style={{ alignItems: "baseline" }}>
                <span className="text-hand text-soft" style={{ fontSize: 14 }}>↻ {s}</span>
                <span style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-fade)" }}>✕</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16">
          <h4 className="text-hand text-navy" style={{ margin: 0, fontSize: 16 }}>熱門關鍵字</h4>
          <GoldRule short style={{ margin: "6px 0 8px" }} />
          <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
            {hotKeywords.slice(0, 5).map(k => <Chip key={k}>{k}</Chip>)}
          </div>
        </div>
      </div>

      {/* right panel */}
      <div style={{ padding: 18 }}>
        <Eyebrow>RECOMMENDED</Eyebrow>
        <Heading>編輯推薦</Heading>
        <div className="text-hand text-soft" style={{ fontSize: 13 }}>還沒想好？從這裡開始。</div>

        <div className="wf-grid col-2 mt-12" style={{ gap: 10 }}>
          {[1, 2, 3, 4].map(i => <HomeCardB key={i} />)}
        </div>

        <div className="mt-16">
          <h4 className="text-hand text-navy" style={{ margin: 0, fontSize: 16 }}>熱門標籤</h4>
          <GoldRule short style={{ margin: "6px 0 8px" }} />
          <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
            {hotTags.map(t => <TagChip key={t.name} size="sm" count={t.count}>#{t.name}</TagChip>)}
          </div>
        </div>
      </div>
      <Note top={-2} left={-4}>左搜尋區<br />右推薦內容</Note>
    </div>
  </Browser>
);

Object.assign(window, { SearchV1, SearchV2, SearchV3 });
