/* GUIDE (在地嚮導) page — 3 wireframe variations + reusable GuideCard */

/* —— Reusable Guide cards —— */

/* GuideCardA — grid card: portrait top, info below */
const GuideCardA = ({ name = "美咲", en = "Misaki", city = "京都", years = 7, langs = "JP · EN", tags = ["茶道", "寺廟", "清晨"], rating = 4.9, articles = 12 }) => (
  <div style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, overflow: "hidden", display: "flex", flexDirection: "column" }}>
    <div style={{ position: "relative" }}>
      <Img height={120} label="嚮導 PORTRAIT" />
      <span style={{
        position: "absolute", top: 8, left: 8,
        background: "rgba(11,34,64,.85)", color: "var(--paper)",
        fontFamily: "var(--sans)", fontSize: 9, letterSpacing: ".18em",
        padding: "3px 8px", borderRadius: 2, textTransform: "uppercase"
      }}>{city}</span>
      <span style={{
        position: "absolute", top: 8, right: 8,
        background: "var(--gold-soft)", color: "var(--navy)",
        fontFamily: "var(--sans)", fontSize: 10, fontWeight: 600,
        padding: "3px 8px", borderRadius: 2
      }}>★ {rating}</span>
    </div>
    <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 6, flex: 1 }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <div className="text-hand" style={{ fontSize: 18, color: "var(--navy)", lineHeight: 1.15 }}>{name}</div>
        <div style={{ fontFamily: "var(--en)", fontSize: 11, color: "var(--ink-light)", fontStyle: "italic" }}>{en}</div>
      </div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", letterSpacing: ".06em" }}>
        {years} 年在地經驗 · {langs}
      </div>
      <Lines n={2} last="short" />
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap", marginTop: 4 }}>
        {tags.map(t => <Chip key={t}>#{t}</Chip>)}
      </div>
      <div className="wf-flex between" style={{ alignItems: "center", marginTop: "auto", paddingTop: 8, borderTop: "1px dashed var(--line-soft)" }}>
        <span style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)" }}>◉ {articles} 篇旅誌</span>
        <Btn variant="ghost">看嚮導 →</Btn>
      </div>
    </div>
  </div>
);

/* GuideCardB — horizontal list row: portrait left, info right, CTA */
const GuideCardB = ({ name = "健一", en = "Kenichi", city = "京都", years = 12, langs = "JP · EN · ZH", tags = ["神社", "夜晚", "山徑"], rating = 4.8 }) => (
  <div style={{ display: "flex", gap: 14, padding: 14, background: "#fff", borderTop: "1.2px solid var(--line-soft)", borderBottom: "1.2px solid var(--line-soft)" }}>
    <div style={{ position: "relative", flexShrink: 0 }}>
      <Img height={100} style={{ width: 100, borderRadius: 999 }} label="頭像" />
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4, minWidth: 0 }}>
      <Eyebrow>GUIDE · {city}</Eyebrow>
      <div className="wf-flex" style={{ alignItems: "baseline", gap: 10 }}>
        <span className="text-hand" style={{ fontSize: 20, color: "var(--navy)" }}>{name}</span>
        <span style={{ fontFamily: "var(--en)", fontSize: 13, color: "var(--ink-light)", fontStyle: "italic" }}>{en}</span>
        <span style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--gold-700)", fontWeight: 600 }}>★ {rating}</span>
      </div>
      <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "var(--ink-light)", letterSpacing: ".06em" }}>
        {years} 年 · {langs}
      </div>
      <Lines n={2} last="short" />
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap", marginTop: 4 }}>
        {tags.map(t => <Chip key={t}>#{t}</Chip>)}
      </div>
    </div>
    <div className="wf-flex col" style={{ justifyContent: "center", flexShrink: 0, gap: 6 }}>
      <Btn>媒合</Btn>
      <Btn variant="ghost">檔案</Btn>
    </div>
  </div>
);

/* GuideCardC — featured: large portrait with overlay name+city, quote pulled */
const GuideCardC = ({ name = "美玲", en = "Mei-Ling", city = "台南", quote = "我帶你走的，是我阿嬤從小走的路。" }) => (
  <div style={{ position: "relative", borderRadius: 4, overflow: "hidden", border: "1.2px solid var(--line-soft)", background: "#fff" }}>
    <Img height={180} label="FEATURED · 嚮導大圖" />
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: 14, background: "linear-gradient(180deg, rgba(11,34,64,0) 0%, rgba(11,34,64,.85) 70%)", color: "var(--paper)" }}>
      <div style={{ fontFamily: "var(--sans)", fontSize: 9, letterSpacing: ".28em", color: "var(--gold-soft)", textTransform: "uppercase", marginBottom: 4 }}>本月精選嚮導 · {city}</div>
      <div className="wf-flex" style={{ alignItems: "baseline", gap: 10, marginBottom: 6 }}>
        <span className="text-hand" style={{ fontSize: 26, color: "var(--paper)" }}>{name}</span>
        <span style={{ fontFamily: "var(--en)", fontSize: 14, fontStyle: "italic", color: "rgba(250,247,238,.7)" }}>{en}</span>
      </div>
      <div className="text-hand" style={{ fontSize: 14, color: "rgba(250,247,238,.85)", lineHeight: 1.5 }}>「{quote}」</div>
    </div>
  </div>
);

const cities = ["全部", "京都", "台南", "清邁", "東京", "峇里島"];

/* —— V1 — Guide directory: hero featured + filter + grid —— */
const GuideV1 = () => (
  <Browser url="yuvatravel.com/guides">
    <WfNav active="嚮導" />

    {/* page head */}
    <div className="wf-section">
      <Eyebrow>GUIDES · 在地嚮導</Eyebrow>
      <Heading size="lg">與真正在地的人 走一段</Heading>
      <Lines n={2} last="short" />
      <div className="text-hand text-soft" style={{ fontSize: 13, marginTop: 6 }}>共 38 位嚮導 · 12 座城市</div>
    </div>

    {/* featured guide */}
    <div className="wf-section" style={{ position: "relative" }}>
      <GuideCardC />
      <Note top={-2} right={-2}>本月精選 · 大圖卡</Note>
    </div>

    {/* filter row */}
    <div className="wf-section" style={{ position: "relative", paddingTop: 0 }}>
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
        {cities.map((c, i) => <Chip key={c} dark={i === 1}>{c}</Chip>)}
      </div>
      <div className="wf-flex between mt-8" style={{ alignItems: "baseline" }}>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>語言：JP · EN · ZH · TH</span>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>排序：最多旅誌 ▾</span>
      </div>
      <Note top={-2} left={-2}>城市分類 + 語言/排序</Note>
    </div>

    {/* grid of guide cards */}
    <div className="wf-section" style={{ position: "relative", paddingTop: 0 }}>
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        <GuideCardA name="美咲" en="Misaki" city="京都" years={7} langs="JP · EN" tags={["茶道", "寺廟", "清晨"]} articles={12} rating={4.9} />
        <GuideCardA name="健一" en="Kenichi" city="京都" years={12} langs="JP · EN" tags={["神社", "夜晚", "山徑"]} articles={9} rating={4.8} />
        <GuideCardA name="美玲" en="Mei-Ling" city="台南" years={5} langs="ZH · EN" tags={["早餐", "市場", "在地"]} articles={15} rating={5.0} />
        <GuideCardA name="阿諾" en="Arnon" city="清邁" years={9} langs="TH · EN" tags={["市場", "山徑", "夜晚"]} articles={8} rating={4.9} />
        <GuideCardA name="優子" en="Yuko" city="東京" years={6} langs="JP · EN" tags={["巷弄", "咖啡", "書店"]} articles={11} rating={4.7} />
        <GuideCardA name="瓦揚" en="Wayan" city="峇里島" years={14} langs="ID · EN" tags={["寺廟", "梯田", "海邊"]} articles={7} rating={4.9} />
      </div>
      <div className="wf-flex center mt-16">
        <Pagination active={1} total={4} />
      </div>
      <Note top={-2} right={-2}>嚮導卡網格 · 3 欄</Note>
    </div>
  </Browser>
);

/* —— V2 — Guide profile detail —— */
const GuideV2 = () => (
  <Browser url="yuvatravel.com/guides/misaki-kyoto">
    <WfNav active="嚮導" />

    {/* breadcrumb */}
    <div className="wf-section" style={{ paddingBottom: 0 }}>
      <div style={{ fontFamily: "var(--hand)", fontSize: 13, color: "var(--ink-light)" }}>
        首頁 / 嚮導 / 京都 / <span style={{ color: "var(--navy)" }}>美咲 Misaki</span>
      </div>
    </div>

    {/* hero: portrait left, summary right */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 14 }}>
        <Img height={200} label="嚮導 大頭照" />
        <div className="wf-flex col" style={{ justifyContent: "space-between" }}>
          <div>
            <Eyebrow>GUIDE · 京都</Eyebrow>
            <div className="wf-flex" style={{ alignItems: "baseline", gap: 12 }}>
              <span className="text-hand" style={{ fontSize: 32, color: "var(--navy)" }}>美咲</span>
              <span style={{ fontFamily: "var(--en)", fontSize: 18, fontStyle: "italic", color: "var(--ink-light)" }}>Misaki Tanaka</span>
            </div>
            <div style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--ink-light)", letterSpacing: ".08em", marginTop: 4 }}>
              7 年在地經驗 · JP · EN · ★ 4.9（38 則）
            </div>
            <Lines n={3} last="short" />
            <div className="wf-flex gap-6 mt-8" style={{ flexWrap: "wrap" }}>
              <Chip>#茶道</Chip><Chip>#寺廟</Chip><Chip>#清晨</Chip><Chip>#東山</Chip>
            </div>
          </div>
          <div className="wf-flex gap-6 mt-8">
            <Btn>媒合美咲</Btn>
            <Btn variant="ghost">收藏</Btn>
            <Btn variant="ghost">分享</Btn>
          </div>
        </div>
      </div>
      <Note top={-2} right={-2}>嚮導頁首 · 大頭照 + 簡介</Note>
    </div>

    {/* about quote */}
    <div className="wf-section bg-paper-2">
      <div style={{ fontFamily: "var(--en)", fontSize: 28, color: "var(--gold)", lineHeight: 1, marginBottom: 6 }}>"</div>
      <div className="text-hand text-navy" style={{ fontSize: 16, lineHeight: 1.7 }}>
        我喜歡在下雨天帶旅人走東山，京都真正的樣子在那時候才會出現⋯
      </div>
      <div className="text-hand text-soft" style={{ fontSize: 12, marginTop: 6 }}>— 美咲，2026 春</div>
    </div>

    {/* expertise / what to expect */}
    <div className="wf-section" style={{ position: "relative" }}>
      <Eyebrow>EXPERTISE · 我擅長帶你看的</Eyebrow>
      <div className="wf-grid col-3 mt-8" style={{ gap: 10 }}>
        {[
          { t: "雨天的東山", d: "繞過清水寺人潮的茶屋路線" },
          { t: "茶道入門", d: "一位旅人也能參加的小席" },
          { t: "錦市場清晨", d: "和料亭廚師一起逛攤位" },
        ].map(x => (
          <div key={x.t} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, padding: 12 }}>
            <div className="text-hand text-navy" style={{ fontSize: 16, marginBottom: 4 }}>{x.t}</div>
            <Lines n={2} last="short" />
            <div className="text-hand text-soft" style={{ fontSize: 11, marginTop: 4 }}>{x.d}</div>
          </div>
        ))}
      </div>
      <Note top={-2} right={-2}>專長 / 路線</Note>
    </div>

    {/* articles by guide */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>美咲的旅誌</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>共 12 篇</span>
      </div>
      <div className="wf-grid col-2 mt-8" style={{ gap: 10 }}>
        <ListCardB /><ListCardB />
      </div>
      <Note top={-2} left={-2}>嚮導文章列表</Note>
    </div>

    {/* reviews */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>REVIEWS · 旅人的回饋</Eyebrow>
      <div className="wf-flex col gap-12 mt-8">
        {[1, 2].map(i => (
          <div key={i} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", padding: 12, borderRadius: 4 }}>
            <div className="wf-flex between" style={{ alignItems: "baseline" }}>
              <span className="text-hand text-navy" style={{ fontSize: 14 }}>Carol · 台北</span>
              <span style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--gold-700)" }}>★★★★★</span>
            </div>
            <Lines n={2} last="short" />
            <span className="text-hand text-soft" style={{ fontSize: 11 }}>2026.03 · 京都 3 天</span>
          </div>
        ))}
      </div>
    </div>

    {/* sticky CTA bar at bottom */}
    <div style={{ position: "sticky", bottom: 0, background: "var(--navy)", color: "var(--paper)", padding: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <div>
        <div className="text-hand" style={{ fontSize: 14, color: "var(--paper)" }}>準備和美咲走一段嗎？</div>
        <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "rgba(250,247,238,.7)" }}>從 NT$ 4,800 / 半日</div>
      </div>
      <Btn>開始媒合 →</Btn>
    </div>
  </Browser>
);

/* —— V3 — Guides by destination (city-grouped) —— */
const GuideV3 = () => (
  <Browser url="yuvatravel.com/guides">
    <WfNav active="嚮導" />

    {/* head */}
    <div className="wf-section">
      <Eyebrow>GUIDES · 依城市瀏覽</Eyebrow>
      <Heading size="lg">你想去哪裡？</Heading>
    </div>

    {/* search */}
    <div className="wf-section" style={{ paddingTop: 0 }}>
      <Search size="lg" placeholder="輸入城市、國家或嚮導名字..." />
    </div>

    {/* by city group */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>京都 · Kyoto</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>3 位嚮導 · 看全部 →</span>
      </div>
      <GoldRule short style={{ margin: "6px 0 10px" }} />
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        <GuideCardA name="美咲" en="Misaki" city="京都" years={7} langs="JP · EN" tags={["茶道", "寺廟", "清晨"]} articles={12} rating={4.9} />
        <GuideCardA name="健一" en="Kenichi" city="京都" years={12} langs="JP · EN" tags={["神社", "夜晚"]} articles={9} rating={4.8} />
        <GuideCardA name="紗智" en="Sachi" city="京都" years={4} langs="JP · EN · ZH" tags={["和菓子", "茶道"]} articles={6} rating={4.9} />
      </div>
      <Note top={-2} right={-2}>城市群組 · 卡片網格</Note>
    </div>

    <div className="wf-section">
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>台南 · Tainan</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>2 位嚮導 · 看全部 →</span>
      </div>
      <GoldRule short style={{ margin: "6px 0 10px" }} />
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        <GuideCardA name="美玲" en="Mei-Ling" city="台南" years={5} langs="ZH · EN" tags={["早餐", "市場"]} articles={15} rating={5.0} />
        <GuideCardA name="阿成" en="A-Cheng" city="台南" years={8} langs="ZH · EN" tags={["巷弄", "夜晚"]} articles={7} rating={4.7} />
      </div>
    </div>

    <div className="wf-section bg-paper-2">
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>清邁 · Chiang Mai</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>4 位嚮導 · 看全部 →</span>
      </div>
      <GoldRule short style={{ margin: "6px 0 10px" }} />
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        <GuideCardA name="阿諾" en="Arnon" city="清邁" years={9} langs="TH · EN" tags={["市場", "山徑"]} articles={8} rating={4.9} />
        <GuideCardA name="妮達" en="Nida" city="清邁" years={6} langs="TH · EN" tags={["寺廟", "工藝"]} articles={11} rating={4.8} />
        <GuideCardA name="頌猜" en="Somchai" city="清邁" years={11} langs="TH · EN · ZH" tags={["夜市", "在地"]} articles={9} rating={4.9} />
      </div>
    </div>
  </Browser>
);

/* —— GuideProfile — individual guide page (uses GuideCardB at top) —— */
const GuideProfile = () => (
  <Browser url="yuvatravel.com/guides/misaki-kyoto">
    <WfNav active="嚮導" />

    {/* breadcrumb */}
    <div className="wf-section" style={{ paddingBottom: 0 }}>
      <div style={{ fontFamily: "var(--hand)", fontSize: 13, color: "var(--ink-light)" }}>
        首頁 / 嚮導 / 京都 / <span style={{ color: "var(--navy)" }}>美咲 Misaki</span>
      </div>
    </div>

    {/* 1) hero — uses GuideCardB component */}
    <div className="wf-section" style={{ position: "relative" }}>
      <Eyebrow>GUIDE PROFILE</Eyebrow>
      <GuideCardB name="美咲" en="Misaki Tanaka" city="京都" years={7} langs="JP · EN" tags={["茶道", "寺廟", "清晨", "東山"]} rating={4.9} />
      <Note top={-2} right={-2}>嚮導卡 B<br />做為頁面 hero</Note>
    </div>

    {/* 2) about quote */}
    <div className="wf-section bg-paper-2">
      <div style={{ fontFamily: "var(--en)", fontSize: 36, color: "var(--gold)", lineHeight: 1, marginBottom: 6 }}>"</div>
      <div className="text-hand text-navy" style={{ fontSize: 16, lineHeight: 1.7 }}>
        我喜歡在下雨天帶旅人走東山，京都真正的樣子，<br />在那時候才會出現⋯
      </div>
      <div className="text-hand text-soft" style={{ fontSize: 12, marginTop: 6 }}>— 美咲，2026 春</div>
    </div>

    {/* 3) about + facts side panel */}
    <div className="wf-section" style={{ position: "relative" }}>
      <Eyebrow>ABOUT · 關於美咲</Eyebrow>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14, marginTop: 8 }}>
        <Lines n={5} last="short" />
        <div style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, padding: 10 }}>
          <div className="text-hand text-soft mb-4" style={{ fontSize: 11, letterSpacing: ".12em", textTransform: "uppercase" }}>FACTS</div>
          <div className="wf-flex col gap-4" style={{ fontFamily: "var(--hand)", fontSize: 13, color: "var(--navy)" }}>
            <div className="wf-flex between"><span className="text-soft">在地</span><span>京都 7 年</span></div>
            <div className="wf-flex between"><span className="text-soft">語言</span><span>JP · EN</span></div>
            <div className="wf-flex between"><span className="text-soft">服務</span><span>半日 / 全日</span></div>
            <div className="wf-flex between"><span className="text-soft">人數</span><span>1–4 人</span></div>
            <div className="wf-flex between"><span className="text-soft">起價</span><span>NT$ 4,800</span></div>
          </div>
        </div>
      </div>
      <Note top={-2} left={-2}>長 bio + 資訊側欄</Note>
    </div>

    {/* 4) signature routes */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Heading>美咲帶你走的路線</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>3 條招牌</span>
      </div>
      <GoldRule short style={{ margin: "6px 0 10px" }} />
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        {[
          { n: "01", t: "雨天的東山", h: "半日 · 4h" },
          { n: "02", t: "茶道入門", h: "半日 · 3h" },
          { n: "03", t: "錦市場清晨", h: "晨間 · 3h" },
        ].map(x => (
          <div key={x.n} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, padding: 10 }}>
            <div className="text-hand text-gold" style={{ fontSize: 22, fontStyle: "italic" }}>{x.n}</div>
            <div className="text-hand text-navy" style={{ fontSize: 16, marginTop: 2 }}>{x.t}</div>
            <Lines n={2} last="short" />
            <div className="wf-flex between mt-4" style={{ alignItems: "baseline" }}>
              <span className="text-hand text-soft" style={{ fontSize: 11 }}>{x.h}</span>
              <span className="text-hand text-navy" style={{ fontSize: 11, borderBottom: "1.5px solid var(--gold-soft)" }}>看路線 →</span>
            </div>
          </div>
        ))}
      </div>
      <Note top={-2} right={-2}>招牌路線</Note>
    </div>

    {/* 5) articles by guide */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <div>
          <Eyebrow>JOURNAL · 美咲的旅誌</Eyebrow>
          <Heading>由美咲記下的故事</Heading>
        </div>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>共 12 篇 →</span>
      </div>
      <div className="wf-grid col-2 mt-8" style={{ gap: 10 }}>
        <ListCardB />
        <ListCardB />
      </div>
      <Note top={-2} left={-2}>嚮導文章列表</Note>
    </div>

    {/* 6) reviews */}
    <div className="wf-section bg-paper-2" style={{ position: "relative" }}>
      <div className="wf-flex between" style={{ alignItems: "baseline" }}>
        <Eyebrow>REVIEWS · 旅人的回饋</Eyebrow>
        <span className="text-hand text-soft" style={{ fontSize: 12 }}>4.9 ★ · 38 則</span>
      </div>
      <div className="wf-grid col-2 mt-8" style={{ gap: 10 }}>
        {[
          { n: "Carol · 台北", d: "2026.03 · 京都 3 天" },
          { n: "Daniel · 香港", d: "2026.02 · 京都 2 天" },
        ].map(r => (
          <div key={r.n} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", padding: 10, borderRadius: 4 }}>
            <div className="wf-flex between" style={{ alignItems: "baseline" }}>
              <span className="text-hand text-navy" style={{ fontSize: 14 }}>{r.n}</span>
              <span style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--gold-700)" }}>★★★★★</span>
            </div>
            <Lines n={2} last="short" />
            <span className="text-hand text-soft" style={{ fontSize: 11 }}>{r.d}</span>
          </div>
        ))}
      </div>
      <Note top={-2} right={-2}>評論卡</Note>
    </div>

    {/* 7) FAQ */}
    <div className="wf-section" style={{ position: "relative" }}>
      <Eyebrow>FAQ · 媒合美咲常見問</Eyebrow>
      <div className="wf-flex col gap-4 mt-8">
        {[
          "媒合流程要花多久？",
          "如果天氣不好可以改期嗎？",
          "家庭旅人 / 帶小孩可以嗎？",
        ].map((q, i) => (
          <div key={q} style={{ background: "#fff", border: "1.2px solid var(--line-soft)", borderRadius: 4, padding: "8px 10px" }}>
            <div className="wf-flex between" style={{ alignItems: "baseline" }}>
              <span className="text-hand text-navy" style={{ fontSize: 14 }}>Q{i + 1}. {q}</span>
              <span className="text-hand text-soft" style={{ fontSize: 14 }}>＋</span>
            </div>
          </div>
        ))}
      </div>
      <Note top={-2} left={-2}>FAQ accordion</Note>
    </div>

    {/* 8) similar guides */}
    <div className="wf-section bg-paper-2">
      <Eyebrow>SIMILAR · 你也可能想認識</Eyebrow>
      <div className="wf-grid col-3 mt-8" style={{ gap: 10 }}>
        <GuideCardA name="健一" en="Kenichi" city="京都" years={12} langs="JP · EN" tags={["神社", "夜晚"]} articles={9} rating={4.8} />
        <GuideCardA name="紗智" en="Sachi" city="京都" years={4} langs="JP · EN · ZH" tags={["和菓子", "茶道"]} articles={6} rating={4.9} />
        <GuideCardA name="優子" en="Yuko" city="東京" years={6} langs="JP · EN" tags={["巷弄", "咖啡"]} articles={11} rating={4.7} />
      </div>
    </div>

    {/* 9) sticky CTA */}
    <div style={{ position: "sticky", bottom: 0, background: "var(--navy)", color: "var(--paper)", padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: "1.5px solid var(--gold)" }}>
      <div>
        <div className="text-hand" style={{ fontSize: 14, color: "var(--paper)" }}>準備和美咲走一段嗎？</div>
        <div style={{ fontFamily: "var(--sans)", fontSize: 10, color: "rgba(250,247,238,.7)", letterSpacing: ".06em" }}>從 NT$ 4,800 / 半日 · 24 小時內回覆</div>
      </div>
      <Btn>媒合美咲 →</Btn>
    </div>
  </Browser>
);

Object.assign(window, { GuideV1, GuideV2, GuideV3, GuideProfile, GuideCardA, GuideCardB, GuideCardC });
