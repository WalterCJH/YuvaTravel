/* ARTICLE DETAIL page — single variant */

const ArticleDetail = () => (
  <Browser url="yuvatravel.com/articles/tainan-old-alley">
    <WfNav active="文章" />

    {/* breadcrumb */}
    <div className="wf-section" style={{ paddingBottom: 0 }}>
      <div style={{ fontFamily: "var(--hand)", fontSize: 13, color: "var(--ink-light)" }}>
        首頁 / 文章 / 台南 / <span style={{ color: "var(--navy)" }}>台南老巷的清晨</span>
      </div>
    </div>

    {/* article header */}
    <div className="wf-section" style={{ position: "relative" }}>
      <Eyebrow>JOURNAL · 03</Eyebrow>
      <Heading size="xl">台南老巷的清晨</Heading>
      <div className="text-hand text-soft" style={{ fontSize: 16, marginTop: 4, lineHeight: 1.3 }}>
        與美玲走一段，從一碗牛肉湯開始的早晨。
      </div>

      {/* meta row */}
      <div className="wf-flex gap-12 mt-12" style={{ flexWrap: "wrap", alignItems: "center" }}>
        <div className="wf-flex gap-4" style={{ alignItems: "center" }}>
          <span style={{ width: 22, height: 22, borderRadius: 999, background: "var(--paper-3)", border: "1.2px solid var(--gold-soft)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--serif)", fontSize: 11, color: "var(--navy)" }}>美</span>
          <span className="text-hand" style={{ fontSize: 14, color: "var(--navy)" }}>陳美玲</span>
        </div>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>📅 2026 年 5 月 3 日</span>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>⏱ 8 分鐘閱讀</span>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>◉ 2,041 觀看</span>
      </div>

      <Note top={2} right={-2}>標題 + 作者 +<br />日期 + 時長 + 觀看</Note>
    </div>

    {/* hero image */}
    <div style={{ padding: "0 16px" }}>
      <Img height={200} label="HERO 圖片 · 全寬" />
    </div>

    {/* article body */}
    <div className="wf-section" style={{ position: "relative" }}>
      <div style={{ maxWidth: 560, margin: "0 auto" }}>
        {/* lead paragraph */}
        <div className="text-hand" style={{ fontSize: 18, color: "var(--navy)", lineHeight: 1.5, fontStyle: "italic", marginBottom: 12 }}>
          清晨五點半，老巷裡的霧還沒散。第一鍋牛肉湯的蒸氣從鐵皮屋頂漏出來，那是這個城市最早醒著的味道。
        </div>

        <Lines n={5} />

        {/* sub-heading */}
        <div className="text-hand text-navy mt-16" style={{ fontSize: 22, fontWeight: 700, letterSpacing: ".02em" }}>
          一、第一鍋湯
        </div>
        <GoldRule short style={{ width: 32, margin: "6px 0 12px" }} />
        <Lines n={4} />

        {/* inline image */}
        <div className="mt-16">
          <Img height={140} label="圖 · 內文搭配" />
          <div className="text-hand text-soft text-center" style={{ fontSize: 12, marginTop: 4, fontStyle: "italic" }}>
            ↑ 凌晨五點半的老店 · 攝於民族路
          </div>
        </div>

        <div className="text-hand text-navy mt-16" style={{ fontSize: 22, fontWeight: 700 }}>
          二、走過七個轉角
        </div>
        <GoldRule short style={{ width: 32, margin: "6px 0 12px" }} />
        <Lines n={3} />

        {/* pull quote */}
        <div style={{ borderLeft: "2px solid var(--gold)", paddingLeft: 14, margin: "20px 0" }}>
          <div className="text-hand" style={{ fontSize: 20, color: "var(--navy)", fontStyle: "italic", lineHeight: 1.4 }}>
            "巷子的盡頭不是出口 — 是另一條巷子的開頭。"
          </div>
        </div>

        <Lines n={3} last="short" />
      </div>
      <Note top={4} right={-2}>內文 720px<br />置中可讀</Note>
    </div>

    {/* tags + share */}
    <div className="wf-section" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
      <div className="wf-flex gap-6" style={{ flexWrap: "wrap" }}>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>標籤：</span>
        <Chip>#台南</Chip>
        <Chip>#早餐</Chip>
        <Chip>#在地</Chip>
        <Chip>#清晨</Chip>
        <Chip>#老巷</Chip>
      </div>
      <div className="wf-flex gap-6">
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>分享 →</span>
        <span className="wf-pill">FB</span>
        <span className="wf-pill">LINE</span>
        <span className="wf-pill">複製連結</span>
      </div>
    </div>

    {/* author bio */}
    <div className="wf-section bg-paper-2">
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center" }}>
        <div style={{ width: 56, height: 56, borderRadius: 999, background: "var(--paper-3)", border: "1.5px solid var(--gold)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--serif)", fontSize: 22, color: "var(--navy)" }}>美</div>
        <div>
          <Eyebrow>GUIDE · TAINAN</Eyebrow>
          <div className="text-hand text-navy" style={{ fontSize: 18, fontWeight: 700, marginTop: 2 }}>陳美玲 · Mei-Ling</div>
          <div className="text-hand text-soft" style={{ fontSize: 13, lineHeight: 1.3 }}>在老巷長大，走了 20 年。早晨先帶你吃一碗牛肉湯。</div>
        </div>
        <Btn variant="ghost">看嚮導 →</Btn>
      </div>
    </div>

    {/* related articles */}
    <div className="wf-section">
      <div className="wf-flex between mb-8" style={{ alignItems: "baseline" }}>
        <Heading>相關文章</Heading>
        <span className="text-hand text-soft" style={{ fontSize: 13 }}>更多 →</span>
      </div>
      <div className="wf-grid col-3" style={{ gap: 10 }}>
        <HomeCardC />
        <HomeCardC />
        <HomeCardC />
      </div>
    </div>

    {/* prev / next nav */}
    <div className="wf-section bg-paper-2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
      <div style={{ borderRight: "1.5px solid var(--gold-soft)", paddingRight: 16 }}>
        <div className="text-hand text-soft" style={{ fontSize: 12 }}>← 上一篇</div>
        <div className="text-hand text-navy" style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>京都的雨．東山的茶</div>
      </div>
      <div style={{ textAlign: "right" }}>
        <div className="text-hand text-soft" style={{ fontSize: 12 }}>下一篇 →</div>
        <div className="text-hand text-navy" style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>清邁的星期天市場</div>
      </div>
    </div>
  </Browser>
);

Object.assign(window, { ArticleDetail });
